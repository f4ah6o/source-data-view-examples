# data-source

**Source → Data**

A thin, headless composition layer that turns external data sources into a small `Data` model.

The first adapter targets kintone:

```text
kintone apps
    ↓
app query
    ↓
join
    ↓
Data query
    ↓
Data(source)
    ↓
data-view
```

The core intentionally has no DOM, React, Vue, state management, or GUI concerns. A GUI edits a serializable `SourceSpec`; execution is a separate step.

## kintone

```ts
import { kintone, type KintoneSourceSpec } from "@f4ah6o/data-source";

const spec: KintoneSourceSpec = {
  kind: "kintone",
  apps: [
    {
      id: "customers",
      app: 10,
      query: 'status = "active"',
      fields: ["customer_id", "name", "status"],
    },
    {
      id: "orders",
      app: 20,
      query: 'date >= "2026-01-01"',
      fields: ["customer_id", "amount", "date"],
    },
  ],
  joins: [
    {
      left: "customers",
      right: "orders",
      type: "left",
      on: { left: "customer_id", right: "customer_id" },
    },
  ],
  query: {
    where: { op: "gt", field: "orders.amount", value: 0 },
    select: ["customers.name", "orders.amount"],
  },
};

const source = kintone(spec, {
  baseUrl: "https://example.cybozu.com",
  apiTokens: {
    customers: process.env.KINTONE_CUSTOMERS_TOKEN!,
    orders: process.env.KINTONE_ORDERS_TOKEN!,
  },
});

const data = await source.load();
```

Credentials are runtime configuration and are deliberately excluded from `SourceSpec`, so the spec can be stored by a GUI without persisting API tokens.

## Data

```ts
type Data = {
  rows: Record<string, unknown>[];
  columns: {
    key: string;
    label?: string;
    type?: string;
    source?: {
      adapter: string;
      app?: string | number;
      field?: string;
    };
  }[];
};
```

App rows are namespaced by source id. After joining `customers` and `orders`, paths such as `customers.name` and `orders.amount` are stable and collision-free.

## Query model

kintone's own query string stays at the app boundary and is pushed down to kintone. The query after joins is a small serializable AST intended to be easy for a GUI to produce.

Supported comparison operators:

- `eq`, `ne`
- `gt`, `gte`, `lt`, `lte`
- `in`
- `contains`
- logical `and`, `or`, `not`

A `DataQuery` may also specify `select`, `orderBy`, and `limit`.

## Join model

Supported joins are `inner`, `left`, `right`, and `full`. Composite keys use an array of key pairs:

```ts
{
  left: "projects",
  right: "costs",
  type: "left",
  on: [
    { left: "company_id", right: "company_id" },
    { left: "project_id", right: "project_id" },
  ],
}
```

## Design boundary

```text
GUI state
   ↓
SourceSpec       serializable / credential-free
   ↓
DataSource.load  I/O boundary
   ↓
Data             source-neutral
   ↓
data-view
```

The kintone adapter uses the Cursor API internally so pagination is not exposed through the public model.

## Development

This repository uses pnpm, Oxlint, and Oxfmt.

```sh
corepack enable
pnpm install
pnpm check
```

Individual commands:

```sh
pnpm fmt
pnpm fmt:check
pnpm lint
pnpm build
pnpm test
```
