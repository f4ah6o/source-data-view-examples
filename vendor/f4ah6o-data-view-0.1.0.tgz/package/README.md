# data-view

`data-view` is a small, headless TypeScript library for turning structured data into views for admin interfaces.

> Data → View

The core boundary is deliberately narrow:

```text
Data + ViewSpec
      ↓
pure functions
      ↓
  ViewModel
────────────── side-effect boundary
   Renderer
```

The package owns the transformation into a renderer-neutral `ViewModel`. It does not own DOM rendering, React/Vue components, state management, or CRUD behavior.

## Primitives

### Table

Turn entity × field data into a two-axis table.

```ts
import { table } from "@f4ah6o/data-view";

const view = table(users, {
  fields: ["name", "role", "status"],
});
```

A one-record detail view and a one-field list can both be represented as tables, so they are not separate primitives in this prototype.

### Tree

Keep hierarchy while selecting the fields that belong in the view.

```ts
import { tree } from "@f4ah6o/data-view";

const view = tree(organizations, {
  fields: ["name", "role"],
  children: (node) => node.children,
});
```

### Matrix

Turn relationships into row × column axes.

```ts
import { matrix } from "@f4ah6o/data-view";

const view = matrix(permissions, {
  row: (item) => item.user,
  column: (item) => item.permission,
  value: (item) => item.granted,
});
```

Each row/column pair represents at most one input item. Duplicate coordinates are rejected because their rendering semantics would otherwise be ambiguous.

### Path-based table / `Data` adapter

`table()` reads fields as direct `keyof T` properties, which doesn't fit a joined `Data` row from `@f4ah6o/data-source`, where a column like `customers.name` may be a flattened literal key (after `select`) or still nested (`row.customers.name`, before `select`). `tablePath` resolves dotted paths either way, and `tableFromData` adapts a `Data`-shaped value (`{ rows, columns }`) straight into a table `ViewModel` without data-view depending on `@f4ah6o/data-source`:

```ts
import { tableFromData } from "@f4ah6o/data-view";
// data: Data from @f4ah6o/data-source, e.g. after composeData + runQuery
const view = tableFromData(data, { fields: ["customers.name", "orders.amount"] });
// spec is optional; omitted `fields` defaults to every column in `data`
```

`tablePath` is the lower-level primitive `tableFromData` is built on, for callers that already have plain rows rather than a full `Data` value:

```ts
import { tablePath } from "@f4ah6o/data-view";

const view = tablePath(rows, { fields: ["customers.name", "orders.amount"] });
```

## Design

- headless and framework agnostic
- functional, stateless API
- pure Data + ViewSpec → ViewModel transformations
- no renderer-specific types in core
- no DOM, React, Vue, state management, or CRUD primitives
- small public API: `table`, `tree`, `matrix`, the path-based `tablePath` / `tableFromData` adapters, and their types
- deterministic ordering based on input/spec order

Renderers can be built as a separate layer against these ViewModels.

## Development

```sh
pnpm install
pnpm lint
pnpm format:check
pnpm test
pnpm typecheck
```
